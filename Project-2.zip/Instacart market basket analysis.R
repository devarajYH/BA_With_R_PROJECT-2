rm(list = ls())
library(ggplot2)
library(readr)
library(arules)
library(arulesViz)
library(data.table)
library(ggplot2)
library(knitr)
library(tidyverse)
library(DT)
library(dplyr)
library(stringr)

# NOTE:
# due to uploading limit in GITHUB i couldnt upload all the Datasets(with bigger size).
# Please refer the following link to download the datasets. link:  https://www.kaggle.com/c/instacart-market-basket-analysis/data

# use the above link to download only order_products__prior.csv & orders.csv files. rest of the files are uploaded in the GITHUB

setwd("C:\Users\dhirannavara\Desktop\Project")
# Datasets are provided in the foler 'Project_Datasets' in compressed file format(to reduce file size)..
# Please download the files and extract them into your local folder and set that folder location as Working Directory

getwd()
products=read.csv("products.csv",header = T)
aisles=read.csv("aisles.csv",header = T)
departments=read.csv("departments.csv",header = T)
order_products__prior=read.csv("order_products__prior.csv",header = T)
order_products__train=read.csv("order_products__train.csv",header = T)
orders=read.csv("orders.csv",header = T)
sample_submission=read.csv("sample_submission.csv",header = T)
summary(products)
summary(aisles)
summary(departments)
summary(order_products__prior)
summary(order_products__train)
summary(sample_submission)

head(aisles)
head(products)
head(departments)
head(order_products__prior)
head(order_products__train)
head(orders)
head(sample_submission)


##orders = orders %>% order(order_hour_of_day = as.numeric(order_hour_of_day), eval_set = as.factor(eval_set))

##products = products %>% mutate(product_name = as.factor(product_name))

##aisles = aisles %>% mutate(aisle = as.factor(aisle))

##departments = departments %>% mutate(department = as.factor(department))

summary(orders)
orders[is.na(orders$days_since_prior_order),] %>% datatable()

#days_since_prior_order
orders %>% 
  ggplot(aes(x=days_since_prior_order)) + 
  geom_histogram(stat="count",fill="cornflowerblue")

#eval_set
orders %>% 
  ggplot(aes(x=eval_set, fill= eval_set )) + 
  geom_bar() + geom_text(aes(label = ..count..), stat='count', vjust=-0.5) + theme(axis.text.x = element_text(angle = 30, size=12))


#order_number
orders %>% 
  ggplot(aes(x=order_number)) + 
  geom_histogram(stat="count",fill="cornflowerblue")



orders %>% filter(eval_set=="prior") %>% count(order_number) %>% ggplot(aes(order_number,n)) + geom_line(color="cornflowerblue", size=1)+geom_point(size=2, color="red")


orders %>% filter(eval_set=="prior") %>% count(days_since_prior_order) %>% ggplot(aes(days_since_prior_order, n)) + geom_line(color="cornflowerblue", size=1)+geom_point(size=2, color="red")

orders %>% 
  ggplot(aes(x= days_since_prior_order, y= order_number)) + 
  geom_point(color= "red", alpha=0.5) + geom_smooth(method= "lm", color= "darkgrey") +
  labs(x= "days_since_prior_order", y= "order_number")



###In other way

###rm(list=ls())
setwd("C:\Users\dhirannavara\Desktop\Project")
getwd()
library(data.table)
library(dplyr)
install.packages("tidyr")
library(tidyr)

aisles <- fread( "aisles.csv")
departments <- fread( "departments.csv")
or_pr_prior <- fread("order_products__prior.csv")
or_pr_train <- fread("order_products__train.csv")
orders <- fread( "orders.csv")
products <- fread("products.csv")
aisles$aisle <- as.factor(aisles$aisle)
departments$department <- as.factor(departments$department)
orders$eval_set <- as.factor(orders$eval_set)
products$product_name <- as.factor(products$product_name)

or_pr_train$user_id <- orders$user_id[match(or_pr_train$order_id, orders$order_id)]

total_prior_orders <- nrow(orders[orders$eval_set=="prior",])

or_pr_prior <- or_pr_prior %>% 
  inner_join(products, by= "product_id" ) 

or_pr_prior$product_name <- NULL

#Metrics on products
product_metrics<- or_pr_prior %>%
  group_by(product_id) %>%
  summarise(pr_total_orders = n(),
            pr_total_orders_ratio = n()/total_prior_orders,
            pr_mean_add_to_cart = mean(add_to_cart_order),
            pr_reordered_times = sum(reordered) 
  )

product_metrics$pr_reordered_ratio = product_metrics$pr_reordered_times / 
  product_metrics$pr_total_orders

# User Metrics -------------------------------------------------------------------
orders$order_dow_hod <- orders$order_dow * 24 + orders$order_hour_of_day

user_metrics <- orders %>% 
  filter(eval_set == "prior") %>%
  group_by(user_id) %>%
  summarise(
    user_total_orders = max(order_number),
    user_mean_dow = mean(order_dow),
    user_mean_hod = mean(order_hour_of_day),
    user_mean_dow_hod = mean(order_dow_hod),
    user_order_frequency = mean(days_since_prior_order, na.rm=T)
  )

test_train_orders <-  orders %>% 
  filter(eval_set != "prior") %>%
  select(user_id, order_id, eval_set, days_since_prior_order)                                

user_metrics <- user_metrics %>%
  inner_join(test_train_orders)



or_pr_prior <- or_pr_prior %>%
  inner_join(orders, by = "order_id")

user_metrics2 <- or_pr_prior %>%
  group_by(user_id) %>%
  summarise(
    user_total_products =n(),
    user_distinct_products = n_distinct(product_id),
    user_total_pr_reorders = sum(reordered)
  )

user_metrics2$user_pr_reorder_ratio = user_metrics2$user_total_pr_reorders/ 
  user_metrics2$user_total_products


user_product_metrics <- or_pr_prior %>%
  group_by(user_id, product_id) %>%
  summarise(up_total_orders = n(),
            up_mean_add_to_cart= mean(add_to_cart_order),        
            up_total_reorders = sum(reordered)
  ) 

rm(or_pr_prior)
gc()

user_product_metrics<-data.frame(user_product_metrics)
write.csv(user_product_metrics, file = "user_product_metrics.csv", row.names = F)
product_metrics<-data.frame(product_metrics)
write.csv(product_metrics, file = "product_metrics.csv", row.names = F)
user_metrics<-data.frame(user_metrics)
write.csv(user_metrics, file = "user_metrics.csv", row.names = F)
user_metrics2<-data.frame(user_metrics2)
write.csv(user_metrics2, file = "user_metrics2.csv", row.names = F)

library(data.table)
library(dplyr)
library(tidyr)
user_product_metrics <- fread( "user_product_metrics.csv")
product_metrics <- fread( "product_metrics.csv")
user_metrics <- fread( "user_metrics.csv")
user_metrics2 <- fread( "user_metrics2.csv")

user_product_metrics <- user_product_metrics %>% 
  inner_join(product_metrics, by= "product_id") 
user_product_metrics <- user_product_metrics %>% 
  inner_join(user_metrics, by= "user_id") 
user_product_metrics <- user_product_metrics %>% 
  inner_join(user_metrics2, by= "user_id")
rm(product_metrics, user_metrics, user_metrics2)
rm(products, aisles, departments,product_metrics, user_metrics, user_metrics2)
gc()



user_product_metrics$up_ttlOrd_ttlusrOrd_ratio = user_product_metrics$up_total_orders / user_product_metrics$user_total_orders
user_product_metrics$up_ttlOrd_ttlprOrd_ratio = user_product_metrics$up_total_orders / user_product_metrics$pr_total_orders
user_product_metrics$up_ATC_pr_ATC_ratio = user_product_metrics$up_mean_add_to_cart / user_product_metrics$pr_mean_add_to_cart
user_product_metrics$up_reorder_ratio = user_product_metrics$up_total_reorders / user_product_metrics$user_total_orders
user_product_metrics$user_total_pr_reorder_ratio <- user_product_metrics$user_total_pr_reorders/
  user_product_metrics$user_total_products
or_pr_train <- fread( "or_pr_train.csv")
train <- user_product_metrics[user_product_metrics$eval_set == "train",]
test <- user_product_metrics[user_product_metrics$eval_set == "test",]

train <- train %>% 
  left_join(or_pr_train %>% select(user_id, product_id, reordered), 
            by = c("user_id", "product_id"))
train$reordered[is.na(train$reordered)] <- 0

train$eval_set <- NULL
train$user_id <- NULL
train$product_id <- NULL
train$order_id <- NULL

test$eval_set <- NULL
test$user_id <- NULL
test$reordered <- NULL

rm(or_pr_train, orders, test_train_orders, user_product_metrics)
gc()

install.packages("xgboost")
library(xgboost)


params <- list(
  "objective"           = "reg:logistic",
  "eval_metric"         = "logloss",
  "eta"                 = 0.1,
  "max_depth"           = 6,
  "min_child_weight"    = 10,
  "gamma"               = 0.70,
  "subsample"           = 0.77,
  "colsample_bytree"    = 0.95,
  "alpha"               = 2e-05,
  "lambda"              = 10
)

train <- as.data.frame(train)
test <- as.data.frame(test)

subtrain <- train # %>% sample_frac(0.1)
X <- xgb.DMatrix(as.matrix(subtrain %>% select(-reordered)), label = subtrain$reordered)
model <- xgboost(data = X, params = params, nrounds = 30)



importance <- xgb.importance(colnames(X), model = model)
xgb.ggplot.importance(importance)
rm(user_product_metrics)
rm(subtrain)
rm(X, importance, subtrain)
gc()



X <- xgb.DMatrix(as.matrix(test %>% select(-order_id, -product_id)))
test$reordered <- predict(model, X)

test$reordered <- (test$reordered > 0.21) * 1

submission <- test %>%
  filter(reordered == 1) %>%
  group_by(order_id) %>%
  summarise(
    products = paste(product_id, collapse = " ")
  )

missing <- data.frame(
  order_id = unique(test$order_id[!test$order_id %in% submission$order_id]),
  products = "None"
)

submission <- submission %>% bind_rows(missing) %>% arrange(order_id)
write.csv(submission, file = "submit.csv", row.names = F)

